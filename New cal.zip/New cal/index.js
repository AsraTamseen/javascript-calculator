let screen = document.getElementById('screen');
buttons = document.querySelectorAll('button');
let screenValue = '';
for (item of buttons) {
     item.addEventListener('click', function(e){
        buttonText = e.target.innerText;
        console.log('Button text is ', buttonText);
        
        if (buttonText == 'C') {
            screenValue = "";
            screen.value = screenValue;
        }
        else if (buttonText == '=') {
            screen.value = eval(screenValue);
        }
        else if (buttonText == 'sin') {
            screen.value = Math.sin(screenValue);
        }
        else if (buttonText == 'cos') {
            screen.value = Math.cos(screenValue);
        }
        else if (buttonText == 'tan') {
            screen.value = Math.tan(screenValue);
        }
        else if (buttonText == 'root') {
            screen.value = Math.sqrt(screenValue);
        }        
        else if (buttonText == 'sqr') {
            screen.value = Math.pow(screenValue,2);
        }
        else if (buttonText == 'log') {
            screen.value = Math.log(screenValue);
        }
        else if (buttonText == 'pi') {
              
            if(screen.value=="")
                {
            screen.value = Math.PI.toFixed(8);
               }
            else{
                screen.value=(3.14159265*screen.value).toFixed(8);
            }
        }
          else if (buttonText == 'del') {
              var x=screen.value;
            screen.value = x.substring(0,x.length-1);
        }
        else if (buttonText == 'per') {
              var val = 0.0;
            val= screen.value;
            screen.value = val*0.01;
        }
        
        else {
            screenValue += buttonText;
            screen.value = screenValue;
        }

    })
}
